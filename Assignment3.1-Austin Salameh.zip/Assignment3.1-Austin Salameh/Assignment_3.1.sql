select e.ename, d.dname, e.deptno
from emp e, dept d
where e.deptno = d.deptno;
select distinct job, loc 
from emp, dept
where emp.deptno= dept.deptno
and emp.deptno = 20;
select ename, dname, loc
from emp, dept
where emp.deptno = dept.deptno
and comm is not null;
select ename, dname
from emp, dept
where emp.deptno = dept.deptno
and ename like '%S%';
select e.ename, e.job, e.deptno, d.dname
from emp e, dept d
where loc = 'OMAHA'; 
select e.ename "Employee", e.empno "EMP#",
m.ename "Manager", m.empno "Mgr#"
from emp e, emp m
where e.mgr= m.empno;
select e.ename "Employee", e.empno "EMP#",
m.ename "Manager", m.empno "Mgr#"
from emp e
left outer join emp m
on (e.mgr= m.empno);
select e.ename, e.job, d.dname, e.sal, s.grade
from emp e, dept d, salgrade s;
select e.ename, e.hiredate
from emp e join emp kobayashi
on (kobayashi.ename = 'KOBAYASHI')
where kobayashi.hiredate<e.hiredate;
select e.ename "Employee", e.hiredate "Emp Hire Date", m.ename "Manager", m.hiredate "Mgr Hire Date"
from emp e, emp m
where e.mgr = m.empno
and e.hiredate < m.hiredate;​