SELECT mgr, MAX(sal)
FROM emp
WHERE mgr IS NOT NULL
GROUP BY mgr;

SELECT ename, hiredate
FROM emp
WHERE deptno =
(SELECT deptno
FROM emp
WHERE ename= 'RADNER')
AND ename <> 'RADNER';

SELECT empno, ename
FROM emp
WHERE sal >
(SELECT AVG(sal)
FROM emp)
ORDER BY sal DESC;

SELECT m.ename "Manager Name", e.ename "Employee Name", e.sal "Salary", e.empno
FROM emp e
JOIN emp m
ON e.mgr = m.empno
WHERE e.sal<
(SELECT avg(sal) FROM emp e);

SELECT empno, ename
FROM emp
WHERE deptno IN
(SELECT deptno
FROM emp
WHERE ename like '%T%');

SELECT ename, deptno, job
FROM emp
WHERE deptno =
(SELECT deptno
FROM dept
WHERE loc = 'ST LOUIS');

SELECT ename, sal
FROM emp
WHERE mgr =
(SELECT empno
FROM emp
WHERE ename = 'PLISKIN');

SELECT d.deptno, e.ename, e.job, d.dname
FROM emp e, dept d
WHERE e.deptno = d.deptno
AND 
d.dname= 'TRADING';

SELECT ename, deptno, job
FROM emp
WHERE deptno <>
(SELECT deptno
FROM dept
WHERE loc LIKE 'OMAHA')
ORDER BY ename;

SELECT empno, ename, sal
FROM emp
WHERE deptno IN
(SELECT deptno
FROM emp
WHERE ename like '%T%')
AND sal >
(SELECT AVG(sal)
from emp);
