DESCRIBE my_employee;

Insert INTO my_employee
VALUES(001, 'Patel', 'Ralph', 'rpatel', 795);

Insert INTO my_employee
VALUES(002, 'Dancs', 'Betty', 'bdancs', 860);

select * from my_employee;

SET ECHO OFF
SET VERIFY OFF
ACCEPT emp_id -
PROMPT 'Enter the employee number: 
ACCEPT emp_fname -
PROMPT 'Enter the employee''s first name: '
ACCEPT emp_lname -
PROMPT 'Enter the employee''s last name: '
ACCEPT emp_sal PROMPT 'Please enter the employee''salary:'
INSERT INTO my_employee
VALUES (&emp_id, '&emp_lname', '&emp_fname',
lower(substr('&emp_fname',1 , 1) ||
substr('&emp_lname', 1, 7)), &emp_sal);
SET VERIFY ON
SET ECHO ON

select * from my_employee;

commit;

update my_employee
set last_name = 'Drexler'
where id = 3;

update my_employee
set salary = 1000
where salary < 900;

select last_name, salary
from my_employee;

delete from my_employee
where last_name = 'Dancs';

commit;

select * from my_employee;

INSERT INTO my_employee
VALUES (&p_id, '&p_last_name', '&p_first_name',
lower(substr('&p_first_name', 1, 1) ||
substr('&p_last_name', 1, 7)), &p_salary);

savepoint problem_15;

delete from my_employee;

select * from my_employee;

rollback to problem_15;

commit;

select * from my_employee;